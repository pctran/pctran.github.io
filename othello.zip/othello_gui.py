#Patrick Tran
#94926433

import tkinter
import othello

class OthelloApplication: 
    def __init__(self):
        self._rows = 1
        self._col = 1
        self._black = 0
        self._white = 0
        self._initial = 0
        self._board_list = []
        self._piece_list = []
        self._initial_board = []
        self._turn_text = 'Turn: NONE'
        self._score_text = 'B: 0   W:0'
        self._root_window = tkinter.Tk()
        self._state = othello.GameState([],0,0,0,0)
        
        self._canvas = tkinter.Canvas(
            master = self._root_window ,width = 400, height = 400,
            background = 'light green')
        self._canvas.grid(
            row = 1, column = 0, padx = 5, pady = 5,
            sticky = tkinter.N + tkinter.S + tkinter.W + tkinter.E)
        
        self._root_window.rowconfigure(0, weight = 1)
        self._root_window.columnconfigure(0, weight = 1)

        self._new_game_button = tkinter.Button(
            master = self._root_window, text = 'New Game',
            font = ('Helvetica', 15), command = self._new_game)
        self._new_game_button.grid(
            row = 0, column = 0, padx = 5, pady = 5,
            sticky = tkinter.N + tkinter.S)

        self._scoreboard = tkinter.Label(
            master = self._root_window, text = self._score_text,
            font = ('Helvetica', 15))
        self._scoreboard.grid(row = 0, column = 0, sticky = tkinter.W)

        self._turn_display = tkinter.Label(
            master = self._root_window, text = self._turn_text,
            font = ('Helvetica', 15))
        self._turn_display.grid(row = 0, column = 0, sticky = tkinter.E)

        self._canvas.bind('<Configure>', self._on_canvas_resized)

        self._root_window.rowconfigure(0, weight = 0)
        self._root_window.rowconfigure(1, weight = 1)
        self._root_window.rowconfigure(2, weight = 0)

    def _draw_move_black(self, event):
        self._turn = 2
        x = event.x
        y = event.y
        canvas_width = self._canvas.winfo_width()
        canvas_height = self._canvas.winfo_height()
        row = int(y/(canvas_height/self._rows))
        col = int(x/(canvas_width/self._col))
        move_pos = [(row + 1, col + 1),(self._turn)]
        self._board_list.append(move_pos)
        piece_width = 1/self._col
        piece_height = 1/self._rows
        self._piece_list.append([(col*(piece_width*canvas_width)),
                           (row*(piece_height*canvas_height)),
                           (col+1)*(piece_width*canvas_width),
                           (row+1) * (piece_height*canvas_height),
                           self._turn])
        self._next_turn()
        self._draw_pieces()
        self._piece_count()

    def _draw_move_white(self, event) -> None:
        self._turn = 1
        x = event.x
        y = event.y
        canvas_width = self._canvas.winfo_width()
        canvas_height = self._canvas.winfo_height()
        row = int(y/(canvas_height/self._rows))
        col = int(x/(canvas_width/self._col))
        move_pos = [(row + 1, col + 1),(self._turn)]
        self._board_list.append(move_pos)
        piece_width = 1/self._col
        piece_height = 1/self._rows
        self._piece_list.append([(col*(piece_width*canvas_width)),
                           (row*(piece_height*canvas_height)),
                           (col+1)*(piece_width*canvas_width),
                           (row+1) * (piece_height*canvas_height),
                           self._turn])
        self._next_turn()
        self._draw_pieces()
        self._piece_count()

    def make_move(self, event) -> None:
        try:
            self._turn = self._state.turn
            x = event.x
            y = event.y
            canvas_width = self._canvas.winfo_width()
            canvas_height = self._canvas.winfo_height()
            row = int(y/(canvas_height/self._rows)) + 1
            col = int(x/(canvas_width/self._col)) + 1
            game = othello.place(self._state, row, col)
            self.update_game(game)
            self._draw_board()
        except othello.InvalidMoveError:
            pass
        except othello.GameOverError:
            self._draw_board()
            self.display_winner()
            self._canvas.bind('<Button-1>', self._nothing)

    def _nothing(self, event) -> None:
        pass
        
    def _draw_board(self) -> None:
        self._canvas.delete(tkinter.ALL)
        self.display_grid()
        self._update_score()
        self._turn = self._state.turn
        self._update_turn()
        canvas_width = self._canvas.winfo_width()
        canvas_height = self._canvas.winfo_height()
        piece_width = 1/self._col
        piece_height = 1/self._rows
        for row in range(self._rows):
            for col in range(self._col):
                if self._state.board[row][col] == 1:
                    self._canvas.create_oval((col*(piece_width*canvas_width)),
                           (row*(piece_height*canvas_height)),
                           (col+1)*(piece_width*canvas_width),
                           (row+1) * (piece_height*canvas_height),
                            fill = 'white', outline = 'white')

                elif self._state.board[row][col] == 2:
                    self._canvas.create_oval((col*(piece_width*canvas_width)),
                           (row*(piece_height*canvas_height)),
                           (col+1)*(piece_width*canvas_width),
                           (row+1) * (piece_height*canvas_height),
                            fill = 'black', outline = 'black')


    def _create_initial_board(self) -> None:
        rows = self._rows
        col = self._col
        for row in range(rows):
            self._initial_board.append([])
        for row in range(rows):
            for space in range(col):
                self._initial_board[row].append(0)
        for piece in self._board_list:
            piece_row = piece[0][0] - 1
            piece_col = piece[0][1] - 1
            piece_turn = piece[1]
            self._initial_board[piece_row][piece_col] = piece_turn
        self.create_game(self._initial_board, self._rows, self._col, self._initial_turn, self._win_cond)

    def _piece_count(self) -> None:
        self._white = 0
        self._black = 0
        for piece in self._piece_list:
            if piece[4] == 1:
                self._white += 1
            elif piece[4] == 2:
                self._black += 1

    def _draw_pieces(self) -> None:
        for piece in self._piece_list:
            if piece[4] == 1:
                self._canvas.create_oval(piece[0],
                                     piece[1],
                                     piece[2],
                                     piece[3]
                                      ,fill = 'white', outline = 'white' )
            elif piece[4] == 2:
                self._canvas.create_oval(piece[0],
                                     piece[1],
                                     piece[2],
                                     piece[3]
                                      ,fill = 'black', outline = 'black' )
                
    def _new_game(self) -> None:
        self._initial = 0
        try:
            self._winner_label.grid_forget()
        except:
            pass
        self._canvas.delete(tkinter.ALL)
        self._state = othello.GameState([],0,0,0,0)
        self._piece_list == []
        self._canvas.bind('<Button-1>', self._nothing)
        
        self._rows_label = tkinter.Label(
            master = self._root_window, text = 'Rows:', font = ('Helvetica', 15))
        self._rows_label.grid(
            row = 3, column = 0, padx = 5, pady = 5, sticky = tkinter.W)
        self._rows_entry = tkinter.Entry(
            master = self._root_window, width = 5, font = ('Times New Roman', 15))
        self._rows_entry.grid(
            row = 3, column = 0, padx = 5, pady = 5, sticky = tkinter.E)

        self._col_label = tkinter.Label(
            master = self._root_window, text = 'Columns:', font = ('Helvetica', 15))
        self._col_label.grid(
            row = 4, column = 0, padx = 5, pady = 5, sticky = tkinter.W)
        self._col_entry = tkinter.Entry(
            master = self._root_window, width = 5, font = ('Helvetica', 15))
        self._col_entry.grid(
            row = 4, column = 0, padx = 5, pady = 5, sticky = tkinter.E)

        self._turn_label = tkinter.Label(
            master = self._root_window, text = 'Turn:', font = ('Helvetica', 15))
        self._turn_label.grid(
            row = 5, column = 0, padx = 5, pady = 5, sticky = tkinter.W)
        self._turn_entry = tkinter.Entry(
            master = self._root_window, width = 5, font = ('Helvetica', 15))
        self._turn_entry.grid(
            row = 5, column = 0, padx = 5, pady = 5, sticky = tkinter.E)

        self._win_cond_label = tkinter.Label(
            master = self._root_window, text = 'Win Condition:', font = ('Helvetica', 15))
        self._win_cond_label.grid(
            row = 6, column = 0, padx = 5, pady = 5, sticky = tkinter.W)
        self._win_cond_entry = tkinter.Entry(
            master = self._root_window, width = 5, font = ('Helvetica', 15))
        self._win_cond_entry.grid(
            row = 6, column = 0, padx = 5, pady = 5, sticky = tkinter.E)

        self._submit_button = tkinter.Button(
            master = self._root_window, text = 'Submit',
            font = ('Helvetica', 15), command = self.submit_info)
        self._submit_button.grid(
            row = 7, column = 0, padx = 5, pady = 5, sticky = tkinter.E)

    def create_game(self, board, rows, col, turn, win_cond) -> None:
        game = othello.GameState(board, rows, col, turn, win_cond)
        self.update_game(game)

    def update_game(self, game_state) -> None:
        updated_game = game_state
        self._state = updated_game
        
    def submit_info(self) -> None:
        self._rows = int(self._rows_entry.get())
        self._col = int(self._col_entry.get())
        self._turn = self.convert_turn(self._turn_entry.get())
        self._initial_turn = self.convert_turn(self._turn_entry.get())
        self._win_cond = self._win_cond_entry.get()


        self._rows_label.grid_forget()
        self._rows_entry.grid_forget()
        self._col_label.grid_forget()
        self._col_entry.grid_forget()
        self._turn_label.grid_forget()
        self._turn_entry.grid_forget()
        self._win_cond_label.grid_forget()
        self._win_cond_entry.grid_forget()
        self._submit_button.grid_forget()
        self.display_grid()
        if self._turn == 2:
            self._initial_black()
            self._canvas.bind('<Button-1>', self._draw_move_black)
        elif self._turn == 1:
            self._initial_white()
            self._canvas.bind('<Button-1>', self._draw_move_white)

    def start_game(self) -> None:
        self._color_label.grid_forget()
        self._next_button.grid_forget()
        self._turn = self._state.turn
        self._update_turn()
        self._create_initial_board()
        self._turn = self._state.turn
        self._update_score()
        self._update_turn()
        self._initial = 2
        self._canvas.bind('<Button-1>', self.make_move)

    def display_winner(self) -> None:
        if othello._winner(self._state) == 2:
            self._winner_label = tkinter.Label(
                master = self._root_window, text = 'Winner: B', font = ('Helvetica', 15))
            self._winner_label.grid(
                row = 2, column = 0, padx = 5, pady = 5, sticky = tkinter.W + tkinter.E)
        if othello._winner(self._state) == 1:
            self._winner_label = tkinter.Label(
                master = self._root_window, text = 'Winner: W', font = ('Helvetica', 15))
            self._winner_label.grid(
                row = 2, column = 0, padx = 5, pady = 5, sticky = tkinter.W + tkinter.E)

    def _initial_black(self) -> None:
        if self._initial == 0:
            self._canvas.bind('<Button-1>', self._draw_move_black)
            
            self._turn = 2
            
            self._black_label = tkinter.Label(
                master = self._root_window, text = 'Place initial black pieces!', font = ('Helvetica', 15))
            self._black_label.grid(
                row = 2, column = 0, padx = 5, pady = 5, sticky = tkinter.W)
            self._next_button = tkinter.Button(
                master = self._root_window, text = 'Next',
                font = ('Helvetica', 15), command = self._initial_white)
            self._next_button.grid(
                row = 2, column = 0, padx = 5, pady = 5, sticky = tkinter.E)
            self._initial += 1

        
        elif self._initial == 1:
            self._canvas.bind('<Button-1>', self._draw_move_black)
            
            self._white_label.grid_forget()
            self._next_button.grid_forget()

            self._turn = 2
            
            self._color_label = tkinter.Label(
                master = self._root_window, text = 'Place initial black pieces!', font = ('Helvetica', 15))
            self._color_label.grid(
                row = 2, column = 0, padx = 5, pady = 5, sticky = tkinter.W)
            self._next_button = tkinter.Button(
                master = self._root_window, text = 'Start Game',
                font = ('Helvetica', 15), command = self.start_game)
            self._next_button.grid(
                row = 2, column = 0, padx = 5, pady = 5, sticky = tkinter.E)

    def _initial_white(self) -> None:
        if self._initial == 0:
            self._canvas.bind('<Button-1>', self._draw_move_white)
            
            self._turn = 1
            
            self._white_label = tkinter.Label(
                master = self._root_window, text = 'Place initial white pieces!', font = ('Helvetica', 15))
            self._white_label.grid(
                row = 2, column = 0, padx = 5, pady = 5, sticky = tkinter.W)
            self._next_button = tkinter.Button(
                master = self._root_window, text = 'Next',
                font = ('Helvetica', 15), command = self._initial_black)
            self._next_button.grid(
                row = 2, column = 0, padx = 5, pady = 5, sticky = tkinter.E)
            self._initial += 1
            
        elif self._initial == 1:
            self._canvas.bind('<Button-1>', self._draw_move_white)
            self._black_label.grid_forget()
            self._next_button.grid_forget()

            self._turn = 1
            
            self._color_label = tkinter.Label(
                master = self._root_window, text = 'Place initial white pieces!', font = ('Helvetica', 15))
            self._color_label.grid(
                row = 2, column = 0, padx = 5, pady = 5, sticky = tkinter.W)
            self._next_button = tkinter.Button(
                master = self._root_window, text = 'Start Game',
                font = ('Helvetica', 15), command = self.start_game)
            self._next_button.grid(
                row = 2, column = 0, padx = 5, pady = 5, sticky = tkinter.E)

    def convert_turn(self, turn) -> None:
        if turn == 'W':
            return 1
        if turn == 'B':
            return 2

    def _next_turn(self):
        if self._turn == 1:
            self._turn = 2
        elif self._turn == 2:
            self._turn = 1

    def _on_canvas_resized(self, event: tkinter.Event) -> None:
        self._canvas.delete(tkinter.ALL)
        if self._initial == 0 or self._initial == 1:
            self._draw_pieces()
        elif self._initial == 2:
            self._draw_board()
        self.display_grid()

    def _update_score(self) -> None:
        self._black = 0
        self._white = 0
        for row in self._state.board:
            for piece in row:
                if piece == 1:
                    self._white += 1
                elif piece == 2:
                    self._black += 1
        self._scoreboard['text'] = 'B: ' + str(self._black) + '   W: ' + str(self._white)

    def _update_turn(self) -> None:
        if self._turn == 1:
            self._turn_display['text'] = 'TURN: W'
        if self._turn == 2:
            self._turn_display['text'] = 'TURN: B'

    def display_grid(self) -> None:
        canvas_width = self._canvas.winfo_width()
        canvas_height = self._canvas.winfo_height()
        self._fracx_mult = 1/self._col
        self._fracy_mult = 1/self._rows
        for col_line in range(self._col):
            self._canvas.create_line(
                canvas_width * self._fracx_mult * (col_line + 1), 0,
                canvas_width * self._fracx_mult * (col_line + 1), canvas_height)
        for row_line in range(self._rows):
            self._canvas.create_line(
                0, canvas_height * self._fracy_mult * (row_line + 1),
                canvas_width, canvas_height * self._fracy_mult * (row_line + 1))
        
    def run(self) -> None:
        self._root_window.mainloop()
            
if __name__ == '__main__':
    OthelloApplication().run()
