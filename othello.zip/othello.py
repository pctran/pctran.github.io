#Patrick Tran
#94926433
#ICS 32 Thornton

''' NONE = 0
    WHITE = 1
    BLACK = 2 '''

class GameState:
    def __init__(self, board, rows, columns ,turn, win_cond):
        self.board = board
        self.rows = rows
        self.columns = columns
        self.turn = turn
        self.win_cond = win_cond

    def show_rows(self) -> int:
        '''returns amount of rows as int'''
        return self.rows
    
    def show_columns(self) -> int:
        '''returns amount of columns as int'''
        return self.columns

    def show_turn(self) -> int:
        '''returns turn as an int
            1 = WHITE 2 = BLACK '''
        return self.turn
    
class InvalidMoveError(Exception):
    '''Raised when invalid move is made'''
    pass

class GameOverError(Exception):
    '''
    Raised when move is attempted after game is already over
    '''
    pass

def show_turn(GameState: 'GameState') -> None:
    '''prints turn'''
    turn = GameState.turn
    if turn == 1:
        pass
    elif turn == 2:
        pass

def show_pieces(GameState: 'GameState') -> None:
    '''prints how many pieces of black and white there are on board'''
    pieces = piece_count(GameState)
    print('B: ' + str(pieces[0]) + '  W: ' + str(pieces[1]))

def place(game_state: 'GameState', row: int, col: int) -> GameState:
    '''handles placing a new piece on board if it is a valid move'''
    game_state = game_state
    new_board = game_state.board
    turn = game_state.turn
    win_cond = game_state.win_cond
    row += -1
    col += -1
    try:
        _opposite_color_adjacent(game_state, row, col, turn)
        _empty_space(game_state, row, col)
    except InvalidMoveError:
        return game_state
    print_valid()
    if turn == 1:
        new_board[row][col] = 1
    if turn == 2:
        new_board[row][col] = 2
    new_board = flip(game_state, row, col, turn)
    new_turn = _next_turn(turn)
    new_GameState = GameState(new_board, game_state.rows, game_state.columns, new_turn, game_state.win_cond)
    if _valid_moves_left(new_GameState) == False:
        valid_turn = _next_turn(new_turn)
        new_GameState = GameState(new_board, game_state.rows, game_state.columns, valid_turn, game_state.win_cond)
        if _valid_moves_left(new_GameState) == False:
            raise GameOverError
        else:
            return(new_GameState)
    return new_GameState
        
def flip(game_state: 'GameState', row: int, col: int, turn: int) -> list:
    '''handles flipping of pieces according to SIMPLE rules'''
    AROUND_COORD = [(1,0),(1,1),(1,-1),
                    (0,-1),(0,1),(-1,0),
                    (-1,1),(-1,-1)]
    
    board = game_state.board
    board[row][col - 1] == 1
    if turn == 1:
        for space in range(8):
            try:
                if board[row + AROUND_COORD[space][0]][col + AROUND_COORD[space][1]] == 2 and row + AROUND_COORD[space][0] >= 0 and col + AROUND_COORD[space][1] >= 0:
                    board[row + AROUND_COORD[space][0]][col + AROUND_COORD[space][1]] = 1
            except IndexError:
                pass
    elif turn == 2:
        for space in range(8):
            try:
                if board[row + AROUND_COORD[space][0]][col + AROUND_COORD[space][1]] == 1 and row + AROUND_COORD[space][0] >= 0 and col + AROUND_COORD[space][1] >= 0:
                    board[row + AROUND_COORD[space][0]][col + AROUND_COORD[space][1]] = 2
            except IndexError:
                pass
    return board
    

def displayGame(GameState: 'GameState') -> None:
    '''prints game according to 0,1,2 and printing .,B,W'''
    show_pieces(GameState)
    current_game = GameState
    rows = current_game.rows
    col = current_game.columns
    for row in range(rows):
        for space in range(col - 1):
            if current_game.board[row][space] == 0:
                print('.', end = ' ')
            elif current_game.board[row][space] == 1:
                print('W', end = ' ')
            elif current_game.board[row][space] == 2:
                print('B', end = ' ')
        if current_game.board[row][-1] == 0:
                print('.', end = '')
        elif current_game.board[row][-1] == 1:
                print('W', end = '')
        elif current_game.board[row][-1] == 2:
                print('B', end = '')
        print()
    _empty_spaces_left(GameState)
    show_turn(GameState)

def piece_count(GameState: 'GameState') -> (int, int):
    '''returns number of black and white pieces as tuple'''
    board = GameState.board
    black = 0
    white = 0
    for row in board:
        for space in row:
            if space == 0:
                pass
            elif space == 1:
                white += 1
            elif space == 2:
                black += 1
    return black, white

def show_winner(game_state: 'GameState') -> None:
    '''prints winner'''
    winner = _winner(game_state)
    if winner == 1:
        print('WINNER: W')
    elif winner == 2:
        print('WINNER: B')

def print_valid() -> None:
    '''prints valid'''
    pass

def _redo_turn_after_invalid() -> None:
    '''used when an invalid input is received and a new
        input needs to be entered'''
    move = input()
    move = move.split()
    row = int(move[0])
    col = int(move[1])
    return (row, col)

def _empty_space(GameState: 'GameState', row: int, col: int) -> None:
    '''shows whether space is empty, if not raises InvalidMoveError'''
    board = GameState.board
    if row > len(board) - 1 or row < 0:
        raise InvalidMoveError
    if col > len(board[0]) - 1 or col < 0:
        raise InvalidMoveError
    if board[row][col] != 0:
        raise InvalidMoveError

def _empty_space_no_print(GameState: 'GameState', row: int, col: int) -> None:
    '''same as _empty_space but doesn't print INVALID'''
    board = GameState.board
    if row > len(board) - 1 or row < 0:
        raise InvalidMoveError
    if col > len(board[0]) - 1 or col < 0:
        raise InvalidMoveError
    if board[row][col] != 0:
        raise InvalidMoveError


def _opposite_color_adjacent(game_state: 'GameState', row: int, col: int, turn: int) -> None:
    '''verifies if move is valid if the space has a piece of
        the opposite color'''
    AROUND_COORD = [(1,0),(1,1),(1,-1),
                    (0,-1),(0,1),(-1,0),
                    (-1,1),(-1,-1)]
    
    board = game_state.board
    opposite_piece_count = 0
    if turn == 1:
        for space in range(8):
            try:
                if board[row + AROUND_COORD[space][0]][col + AROUND_COORD[space][1]] == 2 and row + AROUND_COORD[space][0] >= 0 and col + AROUND_COORD[space][1] >= 0:
                    opposite_piece_count += 1
            except IndexError:
                pass
    elif turn == 2:
        for space in range(8):
            try:
                if board[row + AROUND_COORD[space][0]][col + AROUND_COORD[space][1]] == 1 and row + AROUND_COORD[space][0] >= 0 and col + AROUND_COORD[space][1] >= 0:
                    opposite_piece_count += 1
            except IndexError:
                pass
            
    if opposite_piece_count == 0:
        raise InvalidMoveError

def _opposite_color_adjacent_no_print(game_state: 'GameState', row: int, col: int, turn: int) -> None:
    '''same as _opposite_color_adjacent but doesn't print'''
    AROUND_COORD = [(1,0),(1,1),(1,-1),
                    (0,-1),(0,1),(-1,0),
                    (-1,1),(-1,-1)]
    
    board = game_state.board
    opposite_piece_count = 0
    if turn == 1:
        for space in range(8):
            try:
                if board[row + AROUND_COORD[space][0]][col + AROUND_COORD[space][1]] == 2 and row + AROUND_COORD[space][0] >= 0 and col + AROUND_COORD[space][1] >= 0:
                    opposite_piece_count += 1
            except IndexError:
                pass
    elif turn == 2:
        for space in range(8):
            try:
                if board[row + AROUND_COORD[space][0]][col + AROUND_COORD[space][1]] == 1 and row + AROUND_COORD[space][0] >= 0 and col + AROUND_COORD[space][1] >= 0:
                    opposite_piece_count += 1
            except IndexError:
                pass
            
    if opposite_piece_count == 0:
        raise InvalidMoveError



def _empty_spaces_left(GameState: 'GameState') -> None:
    '''verifies if there are any empty spaces left'''
    board = GameState.board
    spaces = 0
    for row in board:
        for space in row:
            if space == 0:
                spaces += 1
    if spaces == 0:
        raise GameOverError
    
def _next_turn(turn: int) -> int:
    '''changes turn'''
    if turn == 1:
        return 2
    if turn == 2:
        return 1

def _valid_moves_left(game_state: 'GameState') -> bool:
    '''checks if there are valid moves left'''
    valid_count = 0
    board = game_state.board
    rows = game_state.rows - 1
    col = game_state.columns - 1
    turn = game_state.turn
    for row in range(rows):
        for space in range(col):
            if board[row][space] == 0:
                test_state = game_state
                try:
                    _opposite_color_adjacent_no_print(test_state, row, space, turn)
                    valid_count += 1
                except InvalidMoveError:
                   continue
    if valid_count == 0:
        return False
    else:
        return True

def _winner(game_state: 'GameState') -> int:
    win_cond = game_state.win_cond
    if win_cond == 'MOST':
        if piece_count(game_state)[0] > piece_count(game_state)[1]:
            winner = 2
        else:
            winner = 1
    else:
        if piece_count(game_state)[0] > piece_count(game_state)[1]:
            winner = 1
        else:
            winner = 2
    return winner
