/**
 * ai for connect four
 */
public class ConnectFourLogic
{
	
	int moveRow;
	/**
	 * default constructor
	 */
	public ConnectFourLogic()
	{
		moveRow = 0;
	}
	
	
	/**
	 * makes random move between collumns 0 and 6
	 */
	public int makeMove(int[][] board)
	{
		moveRow = (int)Math.round(Math.random()*6);
		return moveRow;
	}
}