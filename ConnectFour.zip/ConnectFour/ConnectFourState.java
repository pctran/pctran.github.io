/**
 * represents connect four game object
*/
public class ConnectFourState
{
	/**
	 * static variables for game logic
	 */
	static final int empty = 0;
	static final int user = 1;
	static final int ai = 2;
	
	static final int rows = 6;
	static final int collumns = 7;
	
	/**
	 * partition between outputs
	 */
	static final String partition = "\n-------------\n\n";
	
	int[][] board;
	int turn;
	int turnNum;
	int winner;
	boolean won;
	
	/**
	 * constructor with who goes first
	 */
	public ConnectFourState(int turn)
	{
		this.board = new int[rows][collumns];
		this.turn = turn;
		turnNum = 0;
		winner = 0;
		won = false;
	}
	/**
	 * constructor with who goes first and importing game board
	 */
	public ConnectFourState(int[][] board, int turn)
	{
		this.board = board;
		this.turn = turn;
		turnNum = 0;
		winner = 0;
		won = false;
	}
	
	/**
	 * @return copy of board
	 */
	public int[][] copyBoard()
	{
		return this.board.clone();
	}
	/**
	 * @return opposite turn number
	 */
	public void changeTurn()
	{
		if(this.turn == 1)
			this.turn = 2;
		else
			this.turn = 1;
	}
	/**
	 * checks whether move in a collumn is valid
	 * @param int collumn 
	 * @return if move is valid
	 */
	public boolean validMove(int collumn)
	{
		if(collumn < 0 || collumn > 6)
			return false;
		for(int row = rows -1; row + 1 > 0; row--)
			if(this.board[row][collumn] == 0)
			{
				return true;
			}
		return false;
	}
	/**
	 * drops piece into collumn
	 * @param collumn
	 */
	public void placePiece(int collumn)
	{
		for(int row = rows -1; row + 1 > 0; row--)
			if(this.board[row][collumn] == 0)
			{
				this.board[row][collumn] = this.turn;
				break;
			}
		changeTurn();
		checkWinner();
		turnNum += 1;
	}
	/**
	 * checks if there is a winning four in a row
	 * @return win status
	 */
	public boolean checkWinner()
	{
		/**
		 * checks horizontal
		 */
		for(int row = 0; row < this.rows; row++)
			{
			for(int collumn = 0; collumn < Math.ceil(this.collumns/2.0); collumn++)
			{
				if(this.board[row][collumn] != 0 && this.board[row][collumn] == this.board[row][collumn + 1] && this.board[row][collumn] == this.board[row][collumn + 2] && this.board[row][collumn] == this.board[row][collumn + 3])
				{
					this.winner = this.board[row][collumn];
					this.won = true;
					return true;
				}
			}
			}
		/**
		 * checks vertical
		 */
		for(int collumn = 0; collumn < this.collumns; collumn++)
		{
			for(int row = 0; row < Math.ceil(this.rows/2.0); row++)
			{
				if(this.board[row][collumn] != 0 && this.board[row][collumn] == this.board[row + 1][collumn] && this.board[row][collumn] == this.board[row + 2][collumn] && this.board[row][collumn] == this.board[row + 3][collumn])
				{
					this.winner = this.board[row][collumn];
					this.won = true;
					return true;
				}
			}
		}
		/**
		 * checks down right
		 */
		for(int row = 0; row < Math.ceil(this.rows/2.0); row++)
		{
		for(int collumn = 0; collumn < Math.ceil(this.collumns/2.0); collumn++)
		{
			if(this.board[row][collumn] != 0 && this.board[row][collumn] == this.board[row + 1][collumn + 1] && this.board[row][collumn] == this.board[row + 2][collumn + 2] && this.board[row][collumn] == this.board[row + 3][collumn + 3])
			{
				this.winner = this.board[row][collumn];
				this.won = true;
				return true;
			}
		}
		}
		/**
		 * checks up left
		 */
		for(int collumn = 0; collumn < Math.ceil(this.collumns/2.0); collumn++)
		{
			for(int row = this.rows - 1; row > Math.ceil(this.rows/2.0); row--)
			{
				if(this.board[row][collumn] != 0 && this.board[row][collumn] == this.board[row - 1][collumn + 1] && this.board[row][collumn] == this.board[row - 2][collumn + 2] && this.board[row][collumn] == this.board[row - 3][collumn + 3])
				{
					this.winner = this.board[row][collumn];
					this.won = true;
					return true;
				}
			}
		}
		return false;
	}
	/**
	 * checks if all moves have been made/board is full
	 * @return if there is a draw
	 */
	public void checkDraw()
	{
		if(turnNum == 42)
			this.won = true;
	}
	/**
	 * displays board
	 */
	public void displayBoard()
	{
		System.out.println("0 1 2 3 4 5 6");
		for(int row = 0; row < this.rows; row++)
		{
			for(int collumn = 0; collumn < this.collumns; collumn++)
			{
				if(this.board[row][collumn] == empty)
				{
					System.out.print('.');
					System.out.print(" ");
				}
				if(this.board[row][collumn] == user)
				{
					System.out.print('X');
					System.out.print(" ");
				}
				if(this.board[row][collumn] == ai)
				{
					System.out.print('O');
					System.out.print(" ");
				}
			}
			System.out.println();
		}
		System.out.print(partition);	
	}
}