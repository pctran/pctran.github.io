import java.util.Scanner;
/**
 * This class is the console for running connect four
 */
public class ConnectFourConsole
{
	static int firstMove;
	static int move;
	public static void main(String[] args)
	{
		/**
		 * Prompting user for who goes first
		 */
		Scanner in = new Scanner(System.in);
		System.out.print("Would you like to go first? (Yes: 1 | No: 2): ");
		firstMove = in.nextInt();
		/**
		 * Checking valid input
		 */
		if(firstMove < 1 || firstMove > 2)
			throw new ArithmeticException("/ 1 or 2");
		/**
		 * creating new game state and ai
		 */
		ConnectFourState game = new ConnectFourState(firstMove);
		ConnectFourLogic bot = new ConnectFourLogic();
		game.displayBoard();
		/**
		 * first move is in center of board
		 */
		if(firstMove == 2)
		{
			game.placePiece(3);
			game.displayBoard();
		}
		/**
		 * loop for making moves on board
		 */
		while(game.won == false)
		{
			System.out.print("Which column would you like to drop a piece? : ");
			move = in.nextInt();
			/**
			 * prompts user for valid input
			 */
			while(game.validMove(move) == false)
			{
				System.out.print("Invalid Move! Try again: ");
				move = in.nextInt();
			}
			game.placePiece(move);
			game.displayBoard();
			game.checkDraw();
			/**
			 * checks for draw or win
			 */
			if(game.won == false)
			{
				int botMove = bot.makeMove(game.board);
				while(game.validMove(botMove) == false)
					{
						botMove = bot.makeMove(game.board);
					}
				game.placePiece(botMove);
				game.displayBoard();
				game.checkDraw();
			}
		}
		/**
		 * game over message, displays who won/draw
		 */
		System.out.println("Game Over!");
		if(game.winner == 1)
			System.out.println("You Win!");
		else if(game.winner == 2)
			System.out.println("Computer Wins!");
		else
			System.out.println("Draw!");
	}
}