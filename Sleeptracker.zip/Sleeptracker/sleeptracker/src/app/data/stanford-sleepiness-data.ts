/* from the Stanford Sleepiness Scale */
/* https://web.stanford.edu/~dement/sss.html */

import { SleepData } from './sleep-data';

export class StanfordSleepinessData extends SleepData {
	public static ScaleValues = [undefined,//Sleepiness scale starts at 1
	'feeling active, vital, alert, or wide awake', //1
	'functioning at high levels, but not at peak; able to concentrate', //2
	'awake, but relaxed; responsive but not fully alert', //3
	'somewhat foggy, let down', //4
	'foggy; losing interest in remaining awake; slowed down', //5
	'sleepy, woozy, fighting sleep; prefer to lie down', //6
	'no longer fighting sleep, sleep onset soon; having dream-like thoughts']; //7

	private loggedValue:number;

	constructor(loggedValue:number, loggedAt:Date = new Date()) {
		super();
		this.loggedValue = loggedValue;
		this.loggedAt = loggedAt;
	}

	summaryString():string {
		return "[SLEEPINESS] " + (1 + this.loggedAt.getMonth()) +
		"/" + this.loggedAt.getDate() +
		"/" + this.loggedAt.getFullYear() +
		" [" + this.loggedAt.getHours() + ":" + this.loggedAt.getMinutes() + "] " +
		StanfordSleepinessData.ScaleValues[this.loggedValue]
		+ " (Level " + this.loggedValue + ")";
	}
	
	icon():string{
		return 'eye';
	}
		
	date():string{
		return (1 + this.loggedAt.getMonth()) +
		"/" + this.loggedAt.getDate() +
		"/" + this.loggedAt.getFullYear();
	}
	
	description():string{
		var sleepiness = this.loggedAt.getMinutes().toString();
		if(sleepiness.length == 1){ sleepiness = "0" + sleepiness;}
		return "At " + this.loggedAt.getHours() + ":" + sleepiness + ", you felt " +
		StanfordSleepinessData.ScaleValues[this.loggedValue] + "."
		+ " (Level " + this.loggedValue + ")";
	}
	
}
