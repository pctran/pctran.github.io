import { Component } from '@angular/core';
import { SleepService } from '../services/sleep.service';
import { SleepData } from '../data/sleep-data';
import { OvernightSleepData } from '../data/overnight-sleep-data';
import { StanfordSleepinessData } from '../data/stanford-sleepiness-data';
import { FormsModule } from '@angular/forms';
import { NavController } from '@ionic/angular';
import { Platform } from '@ionic/angular';

declare var cordova;

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
sleepStart;
sleepEnd;
sleepinessStart;
sleepinessValue;
	constructor(public sleepService:SleepService, public navCtrl: NavController) {
	}

	ngOnInit() {

	}

	/* Ionic doesn't allow bindings to static variables, so this getter can be used instead. */
	get allSleepData() {
		return SleepService.AllSleepData;
	}
	
	generateOvernight() {
		var sleepStartDate = new Date(this.sleepStart);
		var sleepStartDateUTC =  new Date(sleepStartDate.getUTCFullYear(), sleepStartDate.getUTCMonth(), sleepStartDate.getUTCDate(),
		sleepStartDate.getUTCHours(), sleepStartDate.getUTCMinutes(), sleepStartDate.getUTCSeconds());
		var sleepEndDate = new Date(this.sleepEnd);
		var sleepEndDateUTC =  new Date(sleepEndDate.getUTCFullYear(), sleepEndDate.getUTCMonth(), sleepEndDate.getUTCDate(),
		sleepEndDate.getUTCHours(), sleepEndDate.getUTCMinutes(), sleepEndDate.getUTCSeconds());
		var OSD = new OvernightSleepData(sleepStartDateUTC, sleepEndDateUTC);
		this.sleepService.logOvernightData(OSD);
	}
	
	generateSleepiness(){
		var sleepinessNum = this.sleepinessValue;
		var sleepinessStartDate = new Date(this.sleepinessStart);
		var sleepinessStartDateUTC =  new Date(sleepinessStartDate.getUTCFullYear(), sleepinessStartDate.getUTCMonth(), sleepinessStartDate.getUTCDate(),
		sleepinessStartDate.getUTCHours(), sleepinessStartDate.getUTCMinutes(), sleepinessStartDate.getUTCSeconds());
		var SD = new StanfordSleepinessData(sleepinessNum, sleepinessStartDateUTC);
		this.sleepService.logSleepinessData(SD);
	}
	
	goToLogOvernight(){
		this.navCtrl.navigateForward('/LogOvernight');
	}
	
	goToLogSleepiness(){
		this.navCtrl.navigateForward('/LogOvernight');
	}
	
	goToSettings(){
		this.navCtrl.navigateForward('/Settings');
	}
}
