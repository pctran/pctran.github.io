import { Component, OnInit } from '@angular/core';
import { SleepService } from '../../services/sleep.service';
import { SleepData } from '../../data/sleep-data';
import { OvernightSleepData } from '../../data/overnight-sleep-data';
import { StanfordSleepinessData } from '../../data/stanford-sleepiness-data';
import { FormsModule } from '@angular/forms';
import { NavController } from '@ionic/angular';
import { ToastController} from '@ionic/angular';
import { Platform } from '@ionic/angular';

declare var cordova;

@Component({
  selector: 'app-log-overnight',
  templateUrl: './log-overnight.page.html',
  styleUrls: ['./log-overnight.page.scss'],
})
export class LogOvernightPage implements OnInit {
sleepStart;
sleepEnd;
sleepinessStart;
sleepinessValue = 1;
reminderDateStr;

  constructor(public sleepService:SleepService, public navCtrl: NavController, public toastController: ToastController, private platform: Platform) {
		
	}

  ngOnInit() {
  }
	get allSleepData() {
		return SleepService.AllSleepData;
	}
	
	generateOvernight() {
		var sleepStartDate = new Date(this.sleepStart);
		var sleepStartDateUTC =  new Date(sleepStartDate.getUTCFullYear(), sleepStartDate.getUTCMonth(), sleepStartDate.getUTCDate(),
		sleepStartDate.getUTCHours(), sleepStartDate.getUTCMinutes(), sleepStartDate.getUTCSeconds());
		var sleepEndDate = new Date(this.sleepEnd);
		var sleepEndDateUTC =  new Date(sleepEndDate.getUTCFullYear(), sleepEndDate.getUTCMonth(), sleepEndDate.getUTCDate(),
		sleepEndDate.getUTCHours(), sleepEndDate.getUTCMinutes(), sleepEndDate.getUTCSeconds());
		var OSD = new OvernightSleepData(sleepStartDateUTC, sleepEndDateUTC);
		if(this.validDateRange(sleepStartDateUTC, sleepEndDateUTC)==true){
			this.sleepService.logOvernightData(OSD);
			this.presentConfirmation();
		}
		else{
			this.presentError();
		}
	}
  
	generateSleepiness(){
		var sleepinessNum = this.sleepinessValue;
		var sleepinessStartDate = new Date(this.sleepinessStart);
		var sleepinessStartDateUTC =  new Date(sleepinessStartDate.getUTCFullYear(), sleepinessStartDate.getUTCMonth(), sleepinessStartDate.getUTCDate(),
		sleepinessStartDate.getUTCHours(), sleepinessStartDate.getUTCMinutes(), sleepinessStartDate.getUTCSeconds());
		var SD = new StanfordSleepinessData(sleepinessNum, sleepinessStartDateUTC);
		if(this.validSleepinessDate(sleepinessStartDateUTC) == true){
			this.sleepService.logSleepinessData(SD);
			this.presentConfirmation();
		}
		else{
			this.presentError();
		}
	}
	
	validDateRange(sleepStart, sleepEnd){
		var now = new Date();
		console.log(sleepStart);
		console.log(sleepEnd);
		console.log(sleepStart===sleepEnd);
		if(sleepStart > sleepEnd || sleepEnd > now || sleepStart.getTime()===sleepEnd.getTime() || isNaN(sleepStart.getTime()) || isNaN(sleepEnd.getTime())){
			return false;
		}
		else{
			return true;
		}
	}
	
	validSleepinessDate(date){
		var now = new Date();
		if(date > now || isNaN(date.getTime())){
			return false;
		}
		else{
			return true;
		}
	}
	
	validReminderDate(date){
		var now = new Date();
		if(date < now || isNaN(date.getTime())){
			return false;
		}
		else{
			return true;
		}
	}
	
	setReminder(){
		var reminderDate = new Date(this.reminderDateStr);
		var reminderDateUTC =  new Date(reminderDate.getUTCFullYear(), reminderDate.getUTCMonth(), reminderDate.getUTCDate(), reminderDate.getUTCHours(), reminderDate.getUTCMinutes(), reminderDate.getUTCSeconds());
		if(this.validReminderDate(reminderDateUTC) == true){
			this.platform.ready().then(()=> {if(this.platform.is('cordova')){
				cordova.plugins.notification.local.schedule({
					text: "It's time to add to your Sleep Tracker!",
					at: reminderDateUTC
				});
			}
			});
			this.presentNotificationConfirmation();
		}
		else{
			this.presentError();
		}
	}
	
	presentNotificationConfirmation(){
		this.toastController.create({message: 'Reminder has been set!', duration:2500}).then((toast)=>{toast.present();});
	}
	
	presentMoreInfo(){
		this.navCtrl.navigateForward('/moreInfo');
	}
	
	presentConfirmation(){
		this.toastController.create({message: 'Entry has been logged!', duration:2500}).then((toast)=>{toast.present();});
	}
	
	presentError(){
		this.toastController.create({message: 'Date is invalid, please try again.', position: "middle", showCloseButton:true}).then((toast)=>{toast.present();});
	}
	
}
