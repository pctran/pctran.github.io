--Readme document for *author(s)*, *email(s)*, *UCI id(s)*--

1. How long, in hours, did it take you to complete this assignment?
14 hours


2. What online resources did you consult when completing this assignment? (list specific URLs)
https://beta.ionicframework.com/docs/components
http://inf133-fa18.depstein.net/files/lectures/11_19_18-device_resources.pdf
https://github.com/katzer/cordova-plugin-local-notifications/wiki


3. What classmates or other individuals did you consult as part of this assignment? What did you discuss?
None


4. Is there anything special we need to know in order to run your code?
Local Notification does not work on Android 8.0+, so a iOS device is needed to test that part of the application.


--Aim for no more than a few sentences for each of the following questions.--


5. Did you design your app with a particular type of user in mind? If so, whom? Did you design your app specifically for iOS or Android, or both?
I didn't design my app with a particular user in mind. The main point was for the general population to use to track sleep and sleepiness. I did not design specifically for either OS.


6. How can a person log overnight sleep in your app? Why did you choose to support logging overnight sleep in this way?
A person logs overnight sleep by clicking on the "+" button at the bottom right of the screen. From there, you can input sleep time and wake time in the DateTime components.
When done, the user can click "Log sleep", which will log the overnight sleep data. I chose this way because I thought having the "+" button would allow for a better initial view.
I did not want to put data and logging on the same page and I thought that users would want to see their data on the first screen. If users want to add data, then they can easily do
that with the button.


7. How can a person log sleepiness during the day in your app? Why did you choose to support logging sleepiness in this way?
A person logs sleepiness by clicking on the "+" button at the bottom right of the screen. From there, you can input when you felt sleepy and the level of sleepiness. There is also a section
labelled "more info" so that users can see more in depth what each level of sleepiness means. When done, the user can click "Log sleepiness", which will log the overnight sleep data. 
I chose this way, again, because I thought having the "+" button would allow for a better initial view. I did not want to put data and logging on the same page and I thought that users would want 
to see their data on the first screen. If users want to add data, then they can easily do that with the button.


8. How can a person view the data they logged in your app? Why did you choose to support viewing logged data in this way?
The person can view the data right from the home page. I chose this way to have a good initial view.


9. Which feature did you add for A5--using a native device resource, backing up logged data to Firebase, or both? If you used a native device resource, what feature did you add? How does this feature change the app's experience for a user?
I used a native device resource. I used Local Notification to allow users to a set reminder notification for themselves to log data into the app. This changes the app experience 
by allowing forgetful users to stay on top of tracking their sleep.


10. Did you add any "extra" features, such as other data to log, changes to the styling of the app? If so, what did you add? How do these add to the experience of the app?
I did not.
